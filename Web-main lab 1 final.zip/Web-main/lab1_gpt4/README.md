### Лабораторная 1
Сверстать оставшиеся блоки из макета:
https://www.figma.com/file/5AntGd1TrVTdWp39E0U38i/ChatGPT_ru?type=design&mode=design&t=s6yA7FRclRDcGraM-0
"Превосходя все ожидания" и ниже.

### Шпаргалка по flex:
https://tpverstak.ru/flex-cheatsheet/